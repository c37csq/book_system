const config = {
  BASE_IMG_URL: 'http://127.0.0.1:7004/public/uploads/',
  BASE_URL_ADMIN: 'http://127.0.0.1:7004/admin/',
  BASE_URL_DEFAULT: 'http://127.0.0.1:7004/default/'
}
export default config
